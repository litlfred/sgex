#!/bin/bash

# SGEX Workflow Integration Package Installer
# This script installs workflow triggering functionality to branch-listing.html

set -e

echo "🐾 SGEX Workflow Integration Package Installer"
echo "=============================================="
echo ""

# Check if we're in the correct directory
if [[ ! -f "public/branch-listing.html" ]]; then
    echo "❌ Error: This script must be run from the root of the sgex repository"
    echo "   Expected to find public/branch-listing.html in current directory"
    echo ""
    echo "   Please navigate to your sgex repository root and run:"
    echo "   cd /path/to/sgex"
    echo "   bash ./install.sh"
    exit 1
fi

# Check if we're on the deploy branch
current_branch=$(git branch --show-current 2>/dev/null || echo "unknown")
if [[ "$current_branch" != "deploy" ]]; then
    echo "⚠️  Warning: You are on branch '$current_branch', but this package is designed for the 'deploy' branch"
    echo ""
    read -p "   Do you want to continue anyway? (y/N): " -n 1 -r
    echo ""
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "❌ Installation cancelled"
        exit 1
    fi
fi

# Backup original file
echo "📋 Creating backup of original branch-listing.html..."
cp public/branch-listing.html public/branch-listing.html.backup
echo "   ✅ Backup created: public/branch-listing.html.backup"

# Install the modified file
echo ""
echo "🚀 Installing workflow integration..."
cp modified-branch-listing.html public/branch-listing.html
echo "   ✅ Workflow integration installed"

echo ""
echo "🎉 Installation complete!"
echo ""
echo "📝 What was added:"
echo "   • Deploy Branch button - triggers branch-deployment.yml workflow"
echo "   • Deploy Landing button - triggers landing-page-deployment.yml workflow"
echo "   • View Actions link - direct link to GitHub Actions"
echo "   • Proper error handling and user feedback"
echo ""
echo "🔐 Requirements for workflow controls to appear:"
echo "   • User must be authenticated with a GitHub Personal Access Token"
echo "   • Token must have 'actions:write' permission to trigger workflows"
echo ""
echo "📍 The workflow controls appear between the discussion section and preview links"
echo "   for each PR when a user is authenticated."
echo ""
echo "🔄 To restore original version:"
echo "   cp public/branch-listing.html.backup public/branch-listing.html"
echo ""
echo "✨ Workflow integration is now ready to use!"