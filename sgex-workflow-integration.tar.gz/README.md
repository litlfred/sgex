# SGEX Workflow Integration Package

This package adds workflow triggering functionality to the existing `branch-listing.html` file in the deploy branch, enabling users to trigger GitHub Actions workflows directly from the PR preview interface.

## 🚀 Features Added

- **Deploy Branch** button - triggers the `branch-deployment.yml` workflow for the specific PR branch
- **Deploy Landing** button - triggers the `landing-page-deployment.yml` workflow to update the landing page
- **View Actions** link - direct link to GitHub Actions for monitoring workflow progress
- Proper error handling and user feedback for deployment operations
- Seamless integration with existing authentication and UI patterns

## 📋 Requirements

- The sgex repository must be on the `deploy` branch
- For workflow controls to appear, users must be authenticated with a GitHub Personal Access Token
- The GitHub token must have `actions:write` permission to trigger workflows

## 🛠 Installation

### Quick Installation (Recommended)

1. Navigate to your sgex repository root:
   ```bash
   cd /path/to/sgex
   ```

2. Ensure you're on the deploy branch:
   ```bash
   git checkout deploy
   ```

3. Download and extract this package, then run the installer:
   ```bash
   # If you have the package files in a directory:
   cd /path/to/workflow-integration-package
   cp install.sh modified-branch-listing.html /path/to/sgex/
   cd /path/to/sgex
   ./install.sh
   ```

### Manual Installation

1. Navigate to your sgex repository root on the deploy branch
2. Backup the original file:
   ```bash
   cp public/branch-listing.html public/branch-listing.html.backup
   ```
3. Copy the modified file:
   ```bash
   cp modified-branch-listing.html public/branch-listing.html
   ```

## 🔧 How It Works

### Workflow Controls Location
The workflow controls appear between the discussion section and the preview links for each PR card when a user is authenticated.

### Available Actions
1. **🚀 Deploy Branch** - Triggers `branch-deployment.yml` with the PR's branch name
2. **🏠 Deploy Landing** - Triggers `landing-page-deployment.yml` from the deploy branch
3. **📊 View Actions** - Opens GitHub Actions in a new tab

### API Integration
The integration uses the existing GitHub API patterns from the `branch-listing.html` file:
- Uses the same GitHub token authentication system
- Follows the same error handling patterns
- Integrates with existing deployment status checking

### Workflow Triggering
```javascript
// Triggers branch deployment workflow
POST /repos/litlfred/sgex/actions/workflows/branch-deployment.yml/dispatches
{
  "ref": "branch-name",
  "inputs": {
    "branch": "branch-name",
    "force_deployment": false
  }
}

// Triggers landing page deployment workflow  
POST /repos/litlfred/sgex/actions/workflows/landing-page-deployment.yml/dispatches
{
  "ref": "deploy",
  "inputs": {
    "source_branch": "deploy",
    "force_deployment": false
  }
}
```

## 🎨 UI Integration

The workflow controls are styled to match the existing design patterns:
- Uses the same color scheme and typography
- Responsive design that works on mobile devices
- Consistent button styling with the rest of the interface
- Proper loading states and disabled states during workflow execution

## 🔄 Rollback

To restore the original version:
```bash
cp public/branch-listing.html.backup public/branch-listing.html
```

## 🛡 Security

- Only authenticated users can see and use workflow controls
- Uses existing GitHub token validation
- Requires appropriate GitHub token permissions for workflow triggering
- All API calls use the same authentication patterns as the existing code

## 📚 Technical Details

### Files Modified
- `public/branch-listing.html` - Added workflow triggering functionality

### Key Functions Added
- `triggerWorkflow()` - Core function for triggering GitHub Actions workflows
- `handleTriggerWorkflow()` - UI handler with loading states and error handling
- Workflow control state management with `triggeringWorkflows` state

### CSS Classes Added
- `.workflow-controls` - Container for workflow buttons
- `.workflow-btn` - Primary workflow button styling
- `.workflow-btn.secondary` - Secondary workflow button styling
- `.workflow-link` - Styling for workflow-related links

### Dependencies
- Uses existing React components loaded via CDN
- Integrates with existing GitHub API service patterns
- No additional dependencies required

## 🐛 Troubleshooting

### Workflow Controls Don't Appear
- Ensure you're authenticated with a GitHub Personal Access Token
- Check that your token has `actions:write` permissions
- Verify you're viewing the page after authentication

### Workflow Triggering Fails
- Check GitHub token permissions include `actions:write`
- Verify the workflows exist in `.github/workflows/` directory
- Check browser console for detailed error messages
- Ensure you have appropriate repository permissions

### Installation Issues
- Verify you're in the sgex repository root directory
- Ensure you're on the deploy branch
- Check that `public/branch-listing.html` exists

## 📖 Related Pull Requests

This integration builds upon existing workflow functionality added in:
- PR #494 - GitHub Actions integration components
- PR #575 - Workflow status and triggering functionality

The package reuses existing patterns and API methods rather than implementing new functionality.