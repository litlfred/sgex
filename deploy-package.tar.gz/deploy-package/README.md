# GitHub Pages SPA Routing Deployment Package

This package contains the files needed to enable GitHub Pages SPA routing for SGEX.

## Problem
When users directly edit URLs or access SGEX links from external applications, they get HTTP 404 errors from GitHub Pages because it tries to find static files at those paths instead of serving the React app.

## Solution
GitHub Pages requires a `404.html` file at the site root to handle SPA routing. This file needs to be deployed from the `deploy` branch to be placed at `/sgex/404.html` where GitHub Pages can access it.

## Files Included

### Critical Files for GitHub Pages Routing:
- `public/404.html` - GitHub Pages SPA routing handler (REQUIRED at site root)
- `public/index.html` - Route restoration logic for the React app

### Enhanced Error Handling (Recommended):
- `src/components/framework/PageProvider.js` - URL preservation during errors
- `src/components/framework/ErrorHandler.js` - Enhanced error messages  
- `src/components/framework/ErrorHandler.css` - Error styling
- `src/services/dakValidationService.js` - Improved DAK validation

### Test Files (Optional):
- `src/tests/DirectUrlAccess.test.js` - Tests for direct URL access
- `src/tests/BranchSwitchingFix.test.js` - Tests for branch switching
- `src/tests/DAKValidationService.test.js` - Tests for DAK validation

## Installation

1. Copy the files to your deploy branch
2. Run the build process
3. Deploy to GitHub Pages

The `install.sh` script automates this process.

## Architecture

### Current State (Feature Branches):
- Feature branches → `/sgex/branch-name/404.html` (ignored by GitHub Pages)
- Direct URL access → HTTP 404 from GitHub Pages

### After Deploy Branch Installation:
- Deploy branch → `/sgex/404.html` (used by GitHub Pages for ALL routing)
- Direct URL access → Works correctly, preserves URLs, shows proper errors

## Testing
After deployment, test these scenarios:
- Direct access to: `https://yoursite.github.io/sgex/dashboard/user/repo`
- Direct access to: `https://yoursite.github.io/sgex/component-editor/user/repo/component`
- URL editing in browser address bar
- External links to specific SGEX pages

All should preserve the URL and show appropriate content or error messages.