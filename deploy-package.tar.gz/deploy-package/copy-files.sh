#!/bin/bash

# Simple copy script - copies files from this package to the target repository
# Usage: ./copy-files.sh [target-repo-path]

set -e

TARGET_DIR="${1:-.}"

echo "=== Copying GitHub Pages SPA Routing Files ==="
echo "Target directory: $TARGET_DIR"
echo ""

# Critical routing files
echo "Copying critical GitHub Pages routing files..."
cp public/404.html "$TARGET_DIR/public/404.html"
cp public/index.html "$TARGET_DIR/public/index.html"
echo "✓ public/404.html"
echo "✓ public/index.html"

# Enhanced error handling
echo ""
echo "Copying enhanced error handling files..."
mkdir -p "$TARGET_DIR/src/components/framework"
mkdir -p "$TARGET_DIR/src/services"
mkdir -p "$TARGET_DIR/src/tests"

cp src/components/framework/PageProvider.js "$TARGET_DIR/src/components/framework/PageProvider.js"
cp src/components/framework/ErrorHandler.js "$TARGET_DIR/src/components/framework/ErrorHandler.js"
cp src/components/framework/ErrorHandler.css "$TARGET_DIR/src/components/framework/ErrorHandler.css"
cp src/services/dakValidationService.js "$TARGET_DIR/src/services/dakValidationService.js"

echo "✓ src/components/framework/PageProvider.js"
echo "✓ src/components/framework/ErrorHandler.js"  
echo "✓ src/components/framework/ErrorHandler.css"
echo "✓ src/services/dakValidationService.js"

# Test files (optional)
echo ""
echo "Copying test files..."
if [ -f "src/tests/DirectUrlAccess.test.js" ]; then
    cp src/tests/DirectUrlAccess.test.js "$TARGET_DIR/src/tests/DirectUrlAccess.test.js"
    echo "✓ src/tests/DirectUrlAccess.test.js"
fi

if [ -f "src/tests/BranchSwitchingFix.test.js" ]; then
    cp src/tests/BranchSwitchingFix.test.js "$TARGET_DIR/src/tests/BranchSwitchingFix.test.js"
    echo "✓ src/tests/BranchSwitchingFix.test.js"
fi

if [ -f "src/tests/DAKValidationService.test.js" ]; then
    cp src/tests/DAKValidationService.test.js "$TARGET_DIR/src/tests/DAKValidationService.test.js"
    echo "✓ src/tests/DAKValidationService.test.js"
fi

echo ""
echo "Files copied successfully!"
echo ""
echo "Next steps:"
echo "1. Review the copied files in $TARGET_DIR"  
echo "2. Test the changes locally"
echo "3. Commit and deploy"
echo ""
echo "For deploy branch usage:"
echo "  ./install.sh"
echo ""