#!/bin/bash

# GitHub Pages SPA Routing Installation Script for Deploy Branch
# This script applies the GitHub Pages SPA routing fixes to a deploy branch

set -e

echo "=== GitHub Pages SPA Routing Installation ==="
echo ""

# Check if we're in a git repository
if [ ! -d ".git" ]; then
    echo "ERROR: This script must be run from the root of a git repository"
    exit 1
fi

# Check if deploy branch exists
if ! git show-ref --verify --quiet refs/heads/deploy 2>/dev/null; then
    echo "ERROR: Deploy branch not found. Please create a deploy branch first."
    echo "You can create it with: git checkout -b deploy"
    exit 1
fi

# Get current branch
CURRENT_BRANCH=$(git rev-parse --abbrev-ref HEAD)
echo "Current branch: $CURRENT_BRANCH"

# Switch to deploy branch
echo "Switching to deploy branch..."
git checkout deploy

echo ""
echo "=== Installing Critical GitHub Pages SPA Routing Files ==="

# Critical files for GitHub Pages routing
if [ -f "public/404.html" ]; then
    echo "✓ public/404.html already exists"
else
    echo "Installing public/404.html..."
    mkdir -p public
    # The 404.html should be copied from the package
fi

if [ -f "public/index.html" ]; then
    echo "✓ public/index.html already exists"
else
    echo "Installing public/index.html..."
    mkdir -p public
    # The index.html should be copied from the package
fi

echo ""
echo "=== Installing Enhanced Error Handling (Recommended) ==="

# Enhanced error handling files
ERROR_HANDLING_FILES=(
    "src/components/framework/PageProvider.js"
    "src/components/framework/ErrorHandler.js" 
    "src/components/framework/ErrorHandler.css"
    "src/services/dakValidationService.js"
)

for file in "${ERROR_HANDLING_FILES[@]}"; do
    if [ -f "$file" ]; then
        echo "✓ $file already exists"
    else
        echo "Installing $file..."
        mkdir -p "$(dirname "$file")"
        # File should be copied from the package
    fi
done

echo ""
echo "=== Installation Summary ==="
echo ""
echo "Files installed for GitHub Pages SPA routing:"
echo "  - public/404.html (CRITICAL - handles all direct URL access)"
echo "  - public/index.html (CRITICAL - restores routes in React app)"
echo "  - Enhanced error handling components (preserves URLs, better UX)"
echo ""
echo "Next steps:"
echo "1. Review the installed files"
echo "2. Commit the changes: git add . && git commit -m 'Add GitHub Pages SPA routing support'"
echo "3. Push to deploy branch: git push origin deploy"
echo "4. Trigger your GitHub Pages deployment workflow"
echo ""
echo "After deployment, test direct URL access:"
echo "  - https://yoursite.github.io/sgex/dashboard/user/repo"
echo "  - https://yoursite.github.io/sgex/component-editor/user/repo/component"
echo ""
echo "GitHub Pages will use the 404.html at /sgex/404.html to handle all routing."
echo ""

# Return to original branch
if [ "$CURRENT_BRANCH" != "deploy" ]; then
    echo "Returning to original branch: $CURRENT_BRANCH"
    git checkout "$CURRENT_BRANCH"
fi

echo "Installation complete!"