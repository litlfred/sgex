# Fork Selector Implementation - Deploy Branch Application

This archive contains the complete fork selector implementation for the sgex repository.

## What's Included

This implementation adds a fork selector feature to the branch landing page that allows users to:
- View and select from all forks of the repository
- See pull requests from different contributors
- Switch between repositories with visual indicators (🏠 for main repo, 🍴 for forks)
- Get real-time PR filtering based on selected repository

## Files Changed

1. **public/branch-listing.html** - Main UI implementation with fork selector dropdown
2. **src/services/githubService.js** - Backend service methods for fork and PR fetching
3. **src/services/githubService.forks.test.js** - Comprehensive test suite

## How to Apply on Deploy Branch

### Method 1: Manual File Replacement
```bash
# From the repository root on deploy branch:
cp public/branch-listing.html public/
cp src/services/githubService.js src/services/
cp src/services/githubService.forks.test.js src/services/
```

### Method 2: Using Git Patch (Recommended)
```bash
# Apply the git patch:
git apply fork-selector-changes.patch
```

## Testing the Implementation

After applying the changes, you can test the functionality:

```bash
# Run the fork-related tests
npm test -- --testPathPattern=forks

# Build the project to ensure everything works
npm run build

# Start the development server
npm start
```

## Features Implemented

- **Repository dropdown selector** at the top of the landing page
- **Visual indicators** for main repository vs forks
- **Dynamic repository information display**
- **Real-time PR filtering** when switching repositories
- **Smart preview URL handling** for main repo vs fork PRs
- **Comprehensive error handling** and loading states

## Notes

- The implementation maintains all existing functionality
- Fork PRs show clear indication when preview deployments are not available
- The main repository (litlfred/sgex) is selected by default
- All changes are backwards compatible

For more details, see the original PR description and commit messages.